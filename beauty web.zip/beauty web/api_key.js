// WARNING: Keep this file private!  Do not commit your API key to your repository!
window.geminiApiKey = "AIzaSyDNqo1YB--9cRnbnIhZdrpjtzExQow8940"; // Replace with your actual Gemini API key